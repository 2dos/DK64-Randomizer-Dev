"""This module contains the task that generates a seed."""

import codecs
import json
import random
import secrets
import time
import traceback
import zipfile
import logging
from datetime import timezone, datetime
from io import BytesIO
import sys
from opentelemetry import metrics
from randomizer.Patching import BPS as bps
from rq import get_current_job
from randomizer.Enums.Settings import SettingsMap
from randomizer.Fill import Generate_Spoiler
from randomizer.Settings import Settings
from randomizer.Spoiler import Spoiler
from version import version

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler(sys.stdout))
meter = metrics.get_meter("worker")
jobs = meter.create_counter("worker.jobs", unit="jobs")
job_duration = meter.create_histogram("worker.job.duration", unit="s")


def generate_seed(settings_dict):
    """Generate a seed with the given settings."""
    print("Running task with")
    started_at = time.time()
    outcome = "success"
    job = None
    try:
        if isinstance(settings_dict, str):
            settings_dict = json.loads(settings_dict)
        delayed_timestamp = settings_dict.get("delayed_spoilerlog_release", 0)
        # patch = open("./static/patches/shrink-dk64.bps", "rb")
        # original = open("dk64.z64", "rb")
        # patched = BytesIO(bps.patch(original, patch).read())
        if not settings_dict.get("seed"):
            settings_dict["seed"] = random.randint(0, 100000000)
        try:
            job = get_current_job()
            # If the job is not None, we are running in a worker.
            if job is not None:
                # If the job is not none, lets check our retries, if we are retrying lets update the seed to append the retry number.
                if job.retries_left < job.meta["max_retries"]:
                    logger.info("Retrying job: " + str(job.retries_left))
                    current_retries = job.meta["max_retries"] - job.retries_left
                    settings_dict["seed"] = str(settings_dict["seed"]) + "-" + str(current_retries)
        except Exception as e:
            logger.info(e)
        # load_base_rom(default_file=patched)
        original_settings_json = json.dumps({key: value for key, value in settings_dict.items() if key != "seed"})
        seed_salt = "" if settings_dict.get("generate_spoilerlog") else secrets.token_hex(16)
        settings_obj = Settings(cleanup_settings(settings_dict), seed_salt=seed_salt)
        spoiler = Spoiler(settings_obj)
        patch, spoiler, password = Generate_Spoiler(spoiler)
        spoiler.FlushAllExcessSpoilerData()
        return update_seed_results(patch, spoiler, settings_dict, password, delayed_timestamp, original_settings_json)

    except Exception as e:
        outcome = "failure"
        logger.info(traceback.format_exc())
        # Return the error and the type of error.
        error = str(type(e).__name__) + ": " + str(e)
        raise e
        # queue.put(error)
    finally:
        if job is not None:
            attributes = {
                "priority": job.origin,
                "ip": job.meta.get("ip"),
                "branch": job.meta.get("branch"),
                "outcome": outcome,
            }
            # Its not perfect that we're tracking it based on when the job runs, we might end up with orphaned jobs
            # but like, its better than nothing.
            jobs.add(1, attributes)
            # This actually tracks the data we're sending, we're just gonna round here because I don't want to deal
            # with floating data in signoz (to be clear it might be dumb easy, but I'm lazy, someone else check me if they care)
            job_duration.record(int(time.time() - started_at), attributes)
            # TODO: Double check if I need to shrink this more before the job times out
            metrics.get_meter_provider().force_flush(timeout_millis=1000)


def cleanup_settings(settings):
    """Cleanup the settings dictionary."""
    # Convert string data to enums where possible.
    for k, v in settings.items():
        if k in SettingsMap:
            if type(v) is list:
                values = []
                for val in v:
                    if val is None:
                        continue
                    if type(val) is int:
                        values.append(SettingsMap[k](val))
                    else:
                        values.append(SettingsMap[k][val])
                settings[k] = values
            elif type(v) is int:
                settings[k] = SettingsMap[k](v)
            else:
                try:
                    settings[k] = SettingsMap[k][v]
                except Exception:
                    pass
    return settings


def update_seed_results(patch, spoiler, settings_dict, password, delayed_timestamp, original_settings_json):
    """Update the seed results."""
    # Assuming post_body.get("delayed_spoilerlog_release") is an int, and its the number of hours to delay the spoiler log release convert that to time.time() + hours as seconds.
    try:
        spoiler_log_release = int(delayed_timestamp)
    except ValueError:
        spoiler_log_release = 0

    timestamp = time.time()
    if spoiler_log_release == 0:
        # Lets set it to 5 years from now if we don't have a delayed spoiler log release, it'll be deleted after 4 weeks anyway.
        unlock_time = timestamp + 157784760
    else:
        unlock_time = timestamp + (spoiler_log_release * 3600)
    if spoiler.settings.generate_spoilerlog:
        unlock_time = 0

    hash = spoiler.settings.seed_hash
    spoiler_log = json.loads(spoiler.json)
    # Encrypt the time and hash with the encryption key.

    current_seed_number = update_total()
    file_name = str(current_seed_number)
    spoiler_log["Unlock Time"] = unlock_time
    spoiler_log["Generated Time"] = timestamp

    # write the spoiler log to a file in generated_seeds folder. Create the folder if it doesn't exist.
    with open("generated_seeds/" + file_name + ".json", "w") as f:
        f.write(str(json.dumps(spoiler_log)))

    sections_to_retain = [
        "Settings",
        "Cosmetics",
        "Spoiler Hints",
        "Spoiler Hints Data",
        "Generated Time",
        "Item Pool",
    ]
    if spoiler.settings.generate_spoilerlog is False:
        spoiler_log = {k: v for k, v in spoiler_log.items() if k in sections_to_retain}
    else:
        del spoiler_log["Unlock Time"]

    # Always remove Password from the spoiler log.
    if spoiler.settings.has_password:
        try:
            del spoiler_log["Password"]
        except Exception:
            try:
                del spoiler_log["password"]
            except Exception:
                pass

    # Zip all the data into a single file.
    # Create a new zip file
    zip_data = BytesIO()

    with zipfile.ZipFile(zip_data, "w") as zip_file:
        # Write proto instead of xdelta patch (new proto-based format)
        zip_file.writestr("fill_result", patch)
        zip_file.writestr("hash", str(hash))
        zip_file.writestr("spoiler_log", str(json.dumps(spoiler_log)))
        zip_file.writestr("seed_id", str(spoiler.settings.seed_id))
        zip_file.writestr("generated_time", str(timestamp))
        zip_file.writestr("version", version)
        zip_file.writestr("seed_number", str(current_seed_number))
        zip_file.writestr("settings", original_settings_json)
    zip_data.seek(0)
    # Convert the zip to a string of base64 data
    zip_conv = codecs.encode(zip_data.getvalue(), "base64").decode()

    # Store the patch file in generated_seeds folder.
    with open("generated_seeds/" + file_name + ".lanky", "w") as f:
        f.write(zip_conv)
    if password:
        return {"patch": zip_conv, "hash": hash, "seed_number": current_seed_number, "password": password}
    return {"patch": zip_conv, "hash": hash, "seed_number": current_seed_number}


def update_total():
    """Update the total seeds generated."""
    max_retries = 5  # Maximum number of retries
    retry_delay = random.uniform(0, 3)
    for _ in range(max_retries):
        try:
            # Try to read and update the current total
            with open("current_total.cfg", "r+") as f:
                try:
                    current_total = int(f.read())
                except ValueError:
                    # If the file is empty or has invalid content
                    current_total = 0

                current_total += 1
                f.seek(0)  # Move the file pointer to the beginning
                f.write(str(current_total))
                f.truncate()  # Truncate the file to the current length
                break
        except IOError:
            # If a read/write error occurs, wait for a random delay and retry
            time.sleep(retry_delay)

    # Update last_generated_time
    last_generated_time = datetime.now(timezone.utc)
    with open("last_generated_time.cfg", "w") as f:
        f.write(str(last_generated_time))
    return current_total
