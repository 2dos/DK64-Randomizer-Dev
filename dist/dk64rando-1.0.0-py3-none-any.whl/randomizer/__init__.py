"""Classes to generate seeds."""
