"""Generated protobuf common package."""
