"""Library Functions for writing data to ROM."""
