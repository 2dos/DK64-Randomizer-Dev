"""Apply Patch data to the ROM."""

import json
import os
from enum import IntEnum
from datetime import datetime as Datetime
from datetime import timezone
from functools import cached_property
import time
from tempfile import mktemp
from randomizer.Enums.Settings import (
    BananaportRando,
    ColorblindMode,
    DamageAmount,
    FasterChecksSelected,
    FungiTimeSetting,
    GalleonWaterSetting,
    HardModeSelected,
    HardBossesSelected,
    MiscChangesSelected,
    PauseHintSetting,
    ProgressiveHintItem,
    PuzzleRando,
    RemovedBarriersSelected,
    RandomStartingRegion,
    ShockwaveStatus,
    ShuffleLoadingZones,
    SlamRequirement,
    WinConditionComplex,
    WrinklyHints,
)
from randomizer.Enums.Transitions import Transitions
from randomizer.Enums.Types import BarrierItems, Types
import randomizer.ItemPool as ItemPool
from randomizer.Enums.Items import Items
from randomizer.Enums.Switches import Switches
from randomizer.Enums.SwitchTypes import SwitchType
from randomizer.Enums.Kongs import Kongs
from randomizer.Enums.Levels import Levels
from randomizer.Enums.Maps import Maps
from randomizer.Enums.ScriptTypes import ScriptTypes
from randomizer.Enums.DoorType import DoorType
from randomizer.Enums.Enemies import Enemies
from randomizer.Enums.Events import Events
from randomizer.Enums.Locations import Locations
from randomizer.Enums.Minigames import Minigames
from randomizer.Enums.Regions import Regions
from randomizer.Lists.EnemyTypes import enemy_location_list
from randomizer.Lists.Location import LocationListOriginal, PreGivenLocations
from randomizer.Lists.Minigame import BarrelMetaData, MinigameLocationData
from randomizer.Logic import RegionsOriginal
from randomizer.LogicClasses import TransitionFront
from randomizer.Lists.HardMode import HardSelector
from randomizer.Lists.Multiselectors import QoLSelector, RemovedBarrierSelector, FasterCheckSelector
from randomizer.Lists.Switches import SwitchData
from randomizer.Patching.BananaPlacer import randomize_cbs
from randomizer.Patching.BananaPortRando import randomize_bananaport, move_bananaports
from randomizer.Patching.BarrelRando import randomize_barrels
from randomizer.Patching.CoinPlacer import randomize_coins, place_mayhem_coins
from randomizer.Patching.Cosmetics.TextRando import writeBootMessages
from randomizer.Patching.Cosmetics.Puzzles import updateMillLeverTexture, updateCryptLeverTexture, updateDiddyDoors, updateHelmFaces, updateSnidePanel
from randomizer.Patching.Cosmetics.Colorblind import addBalloonBulb
from randomizer.Patching.CosmeticColors import (
    applyHelmDoorCosmetics,
    applyKongModelSwaps,
    showWinCondition,
)
from randomizer.Patching.CratePlacer import randomize_melon_crate
from randomizer.Patching.CrownPlacer import randomize_crown_pads
from randomizer.Patching.DoorPlacer import place_door_locations, remove_existing_indicators, alterStoryCutsceneWarps, placeVanillaTNSScripts
from randomizer.Patching.EnemyRando import randomize_enemies
from randomizer.Patching.EntranceRando import (
    enableTriggerText,
    filterEntranceType,
    randomize_entrances,
    placeLevelOrder,
)
from randomizer.Patching.FairyPlacer import PlaceFairies
from randomizer.Patching.ItemRando import place_randomized_items, alterTextboxRequirements, calculateInitFileScreen, place_spoiler_hint_data
from randomizer.Patching.KasplatLocationRando import randomize_kasplat_locations
from randomizer.Patching.KongRando import apply_kongrando_cosmetic
from randomizer.Patching.Library.Scripts import addNewScript, replaceScriptLines, setProgSlamStrength
from randomizer.Patching.Library.Generic import setItemReferenceName, IsItemSelected, getProgHintBarrierItem, getHintRequirementBatch, IsDDMSSelected, ReqItems
from randomizer.Patching.Library.Assets import CompTextFiles, ItemPreview
from randomizer.Patching.MiscSetupChanges import (
    randomize_setup,
    updateKrushaMoveNames,
    updateRandomSwitches,
    updateSwitchsanity,
    remove5DSCameraPoint,
)
from randomizer.Patching.MoveLocationRando import place_pregiven_moves, randomize_moves
from randomizer.Patching.Patcher import LocalROM
from randomizer.Patching.PhaseRando import randomize_helm, randomize_krool
from randomizer.Patching.PriceRando import randomize_prices
from randomizer.Patching.ProtoAdapter import create_patching_adapter
from randomizer.Patching.PuzzleRando import randomize_puzzles, shortenCastleMinecart
from randomizer.Patching.ShipPlacer import PlaceShip
from randomizer.Patching.ShopRandomizer import ApplyShopRandomizer
from randomizer.Patching.UpdateHints import (
    PushHints,
    replaceIngameText,
    PushItemLocations,
    PushHelpfulHints,
    PushHintTiedRegions,
)
from randomizer.Patching.ASMPatcher import patchAssembly, precalcBoot
from randomizer.Patching.ScriptPatcher import patchScripts
from randomizer.Patching.MirrorMode import ApplyMirrorMode
from randomizer.CompileHints import getHelmOrderHint
from randomizer.ProtoSerializer import apply_resolved_settings, fill_result_to_proto
from randomizer.proto_gen import fill_result_pb2
from collections import defaultdict
from copy import deepcopy

# from randomizer.Spoiler import Spoiler


class BooleanProperties:
    """Class to store data relating to boolean properties."""

    def __init__(self, check, offset, target=1):
        """Initialize with given data."""
        self.check = check
        self.offset = offset
        self.target = target


class WinConROM(IntEnum):
    """Enum of all win con types."""

    # If it's not listed here, then it's been reworked into some other win con type under the hood
    krool = 0
    krem_kapture = 2
    custom_item = 3
    rap = 4
    tasks = 8
    tasks_nopause = 9
    flag = 10
    reqitem_solo = 11


def writeMultiselector(
    enabled_selections: list,
    selector: list[dict],
    selection_enum,
    data_length: int,
    ROM_COPY: LocalROM,
    write_start: int,
):
    """Write multiselector choices to ROM."""
    write_data = [0] * data_length
    for item in selector:
        if item["shift"] >= 0:
            if selection_enum[item["value"]] in enabled_selections:
                offset = int(item["shift"] >> 3)
                check = int(item["shift"] % 8)
                write_data[offset] |= 0x80 >> check
    ROM_COPY.seek(write_start)
    for byte_data in write_data:
        ROM_COPY.writeMultipleBytes(byte_data, 1)


def encPass(spoiler) -> int:
    """Encrypt the password."""
    # Try to import randomizer.Encryption encrypt function, if we can pass all args to it.
    try:
        from randomizer.Encryption import encrypt

        return encrypt(spoiler)
    except Exception as e:
        print(e)
        return 0, 0


def patching_response(fill_result_or_spoiler, settings=None, rom=None):
    """Apply the patch data to the ROM in the local server to be returned to the client.

    Args:
        fill_result_or_spoiler: Either a FillResult proto (new path) or Spoiler object (legacy path)
        settings: Settings object (required when fill_result_or_spoiler is a FillResult proto)
        rom: Optional ROM object to patch (browser case). If None, loads from file (server case).
    """
    patch_rng_seed = None
    # Handle both old (Spoiler) and new (FillResult proto + Settings) APIs
    if isinstance(fill_result_or_spoiler, fill_result_pb2.FillResult):
        # New proto-based path - convert proto to adapter object
        fill_result = fill_result_or_spoiler
        if settings is None:
            raise ValueError("settings parameter required when using FillResult proto")
        spoiler = create_patching_adapter(fill_result, settings)

        # Apply Fill
        if len(fill_result.misc_data.level_portal_destinations) > 0:
            settings.level_portal_destinations = [{"map": int(dest.map), "exit": int(dest.exit)} for dest in fill_result.misc_data.level_portal_destinations]
        if len(fill_result.misc_data.level_void_maps) > 0:
            settings.level_void_maps = [int(m) for m in fill_result.misc_data.level_void_maps]

        if fill_result.misc_data.HasField("archipelago"):
            settings.archipelago = bool(fill_result.misc_data.archipelago)
        if fill_result.misc_data.HasField("player_name"):
            settings.player_name = str(fill_result.misc_data.player_name)
        elif not hasattr(settings, "player_name"):
            settings.player_name = ""
        if len(fill_result.misc_data.krool_keys_required) > 0:
            settings.krool_keys_required = [Events(int(e)) for e in fill_result.misc_data.krool_keys_required]
        if len(fill_result.misc_data.starting_kong_list) > 0:
            settings.starting_kong_list = [Kongs(int(k)) for k in fill_result.misc_data.starting_kong_list]
            # Keep the derived count honest.
            settings.starting_kongs_count = len(settings.starting_kong_list)
        if fill_result.misc_data.HasField("resolved_starting_kong"):
            settings.starting_kong = Kongs(int(fill_result.misc_data.resolved_starting_kong))

        # Display hash
        if len(fill_result.misc_data.seed_hash) > 0:
            settings.seed_hash = [int(d) for d in fill_result.misc_data.seed_hash]

        # Restore Fill-mutated B.Locker / T&S arrays
        if len(fill_result.misc_data.blocker_entry_counts) > 0:
            settings.BLockerEntryCount = [int(c) for c in fill_result.misc_data.blocker_entry_counts]
        if len(fill_result.misc_data.blocker_entry_items) > 0:
            settings.BLockerEntryItems = [BarrierItems(int(i)) for i in fill_result.misc_data.blocker_entry_items]
        if len(fill_result.misc_data.boss_bananas) > 0:
            settings.BossBananas = [int(c) for c in fill_result.misc_data.boss_bananas]
        if len(fill_result.misc_data.hint_door_item_counts_level) > 0:
            settings.hint_door_item_counts_level = [int(c) for c in fill_result.misc_data.hint_door_item_counts_level]

        # Everything else generation rolled
        apply_resolved_settings(fill_result.misc_data, settings)
        patch_rng_seed = fill_result.misc_data.patch_rng_seed

        # Initialize valid_locations on settings - required for patching functions
        settings.update_valid_locations(spoiler)

    else:
        # Legacy path - treat as Spoiler object
        spoiler = fill_result_or_spoiler

    # Seed patch randomness
    if patch_rng_seed is not None:
        spoiler.settings.random.seed(patch_rng_seed)
    else:
        spoiler.settings.set_seed()

    # Write date to ROM for debugging purposes
    try:
        temp_json = json.loads(spoiler.json)
        if "Settings" not in temp_json:
            temp_json["Settings"] = {}
    except Exception:
        temp_json = {"Settings": {}}
    dt = Datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    temp_json["Settings"]["Generation Timestamp"] = dt
    spoiler.json = json.dumps(temp_json, indent=4)

    # Use provided ROM if available (browser case), otherwise load from file (server case)
    if rom is not None:
        ROM_COPY = rom
    else:
        ROM_COPY = LocalROM()

    ROM_COPY.seek(0x1FFF200)
    ROM_COPY.writeBytes(dt.encode("ascii"))
    # Initialize Text Changes
    spoiler.text_changes = {}

    # Starting index for our settings
    sav = spoiler.settings.rom_data
    placeVanillaTNSScripts(ROM_COPY)

    # Shuffle Levels
    if spoiler.settings.shuffle_loading_zones == ShuffleLoadingZones.levels:
        # Update Level Order
        vanilla_lobby_entrance_order = [
            Transitions.IslesMainToJapesLobby,
            Transitions.IslesMainToAztecLobby,
            Transitions.IslesMainToFactoryLobby,
            Transitions.IslesMainToGalleonLobby,
            Transitions.IslesMainToForestLobby,
            Transitions.IslesMainToCavesLobby,
            Transitions.IslesMainToCastleLobby,
            Transitions.IslesMainToHelmLobby,
        ]
        vanilla_lobby_exit_order = [
            Transitions.IslesJapesLobbyToMain,
            Transitions.IslesAztecLobbyToMain,
            Transitions.IslesFactoryLobbyToMain,
            Transitions.IslesGalleonLobbyToMain,
            Transitions.IslesForestLobbyToMain,
            Transitions.IslesCavesLobbyToMain,
            Transitions.IslesCastleLobbyToMain,
            Transitions.IslesHelmLobbyToMain,
        ]
        level_order = []
        for level in vanilla_lobby_entrance_order:
            level_order.append(vanilla_lobby_exit_order.index(spoiler.shuffled_exit_data[int(level)].reverse))
        placeLevelOrder(spoiler, level_order, ROM_COPY)

    ROM_COPY.seek(sav + 0x151)
    ROM_COPY.writeMultipleBytes(spoiler.settings.starting_kong, 1)

    boolean_props = [
        BooleanProperties(spoiler.settings.fast_start_beginning_of_game, 0x2E),  # Fast Start Game
        BooleanProperties(spoiler.settings.enable_tag_anywhere, 0x30),  # Tag Anywhere
        BooleanProperties(spoiler.settings.no_melons, 0x128),  # No Melon Drops
        BooleanProperties(spoiler.settings.bonus_barrel_auto_complete, 0x126),  # Auto-Complete Bonus Barrels
        BooleanProperties(spoiler.settings.warp_to_isles, 0x135),  # Warp to Isles
        BooleanProperties(spoiler.settings.ice_traps_damage, 0x150),  # Enable Ice Trap Damage
        BooleanProperties(spoiler.settings.shorten_boss, 0x13B),  # Shorten Boss Fights
        BooleanProperties(spoiler.settings.fast_warps, 0x13A),  # Fast Warps
        BooleanProperties(spoiler.settings.auto_keys, 0x15B),  # Auto-Turn Keys
        BooleanProperties(IsItemSelected(spoiler.settings.cb_rando_enabled, spoiler.settings.cb_rando_list_selected, Levels.DKIsles), 0x10B),  # 5 extra medal handling
        BooleanProperties(spoiler.settings.helm_hurry, 0xAE),  # Helm Hurry
        BooleanProperties(spoiler.settings.wrinkly_available, 0x52),  # Remove Wrinkly Kong Checks
        BooleanProperties(
            spoiler.settings.bananaport_rando in (BananaportRando.crossmap_coupled, BananaportRando.crossmap_decoupled),
            0x47,
        ),  # Parent Map Filter
        BooleanProperties(spoiler.settings.shop_indicator, 0x134, 2),  # Shop Indicator
        BooleanProperties(spoiler.settings.open_lobbies, 0x14C, 0xFF),  # Open Lobbies
        BooleanProperties(spoiler.settings.item_reward_previews, 0x101, 255),  # Bonus Matches Contents
        BooleanProperties(spoiler.settings.fix_lanky_tiny_prod, 0x114),  # Fix Lanky Tiny Prod
        BooleanProperties(spoiler.settings.enemy_kill_crown_timer, 0x35),  # Enemy crown timer reduction
        BooleanProperties(spoiler.settings.race_coin_rando, 0x94),  # Race Coin Location Rando
        BooleanProperties(spoiler.settings.disable_racing_patches, 0x91),  # Disable Racing Patches
        BooleanProperties(spoiler.settings.shops_dont_cost, 0x95),  # Shops don't cost
        BooleanProperties(spoiler.settings.snide_reward_rando, 0x69),  # Snides has rewards
        BooleanProperties(spoiler.settings.free_trade_cbs, 0x10E),  # FTA CBs
    ]

    for prop in boolean_props:
        if prop.check:
            ROM_COPY.seek(sav + prop.offset)
            ROM_COPY.write(prop.target)

    # Fast Hideout
    ROM_COPY.seek(sav + 0x031)
    # The HelmSetting enum is indexed to allow this.
    ROM_COPY.write(int(spoiler.settings.helm_setting))

    # Crown Door & Coin Door
    # Crown Door
    ROM_COPY.seek(sav + 0x4C)
    ROM_COPY.write(int(spoiler.settings.crown_door_item))
    ROM_COPY.write(spoiler.settings.crown_door_item_count)
    # Coin Door
    ROM_COPY.seek(sav + 0x4E)
    ROM_COPY.write(int(spoiler.settings.coin_door_item))
    ROM_COPY.write(spoiler.settings.coin_door_item_count)

    if spoiler.settings.pause_hints_setting == PauseHintSetting.lockout:
        ROM_COPY.seek(sav + 0x136)
        per_hint = (spoiler.settings.pause_hints_lockout_timer * 30) / 4
        ROM_COPY.writeMultipleBytes(int(per_hint), 2)

    kong_free_switches = [
        Switches.JapesFreeKong,
        Switches.AztecLlamaPuzzle,
        Switches.AztecOKONGPuzzle,
        Switches.FactoryFreeKong,
    ]
    if spoiler.settings.switchsanity_enabled:
        for slot in spoiler.settings.switchsanity_data:
            slot_data = spoiler.settings.switchsanity_data[slot]
            rom_offset = slot_data.rom_offset
            pad_kong = slot_data.kong
            pad_type = slot_data.switch_type
            if rom_offset is not None:
                # ROM Write
                ROM_COPY.seek(sav + rom_offset)
                if slot == Switches.IslesMonkeyport:
                    if pad_kong == Kongs.lanky:
                        ROM_COPY.writeMultipleBytes(2, 1)
                    elif pad_kong == Kongs.donkey:
                        ROM_COPY.writeMultipleBytes(1, 1)
                elif slot == Switches.IslesHelmLobbyGone:
                    if pad_type == SwitchType.MiscActivator:
                        if pad_kong == Kongs.donkey:
                            ROM_COPY.writeMultipleBytes(6, 1)
                        elif pad_kong == Kongs.diddy:
                            ROM_COPY.writeMultipleBytes(7, 1)
                    elif pad_type != SwitchType.PadMove:
                        ROM_COPY.writeMultipleBytes(int(pad_kong) + 1, 1)
                elif slot in kong_free_switches:
                    ROM_COPY.writeMultipleBytes(int(pad_kong), 1)
                else:
                    ROM_COPY.writeMultipleBytes(int(pad_kong) + 1, 1)
            else:
                # Only modify the instance script
                if pad_type == SwitchType.GunSwitch:
                    KONG_PELLETS = [48, 36, 42, 43, 38]
                    if pad_kong == Kongs.any:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 24 | {KONG_PELLETS[slot_data.default_kong]} 1 0": "COND 16 | 4 1 0"})
                    else:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 24 | {KONG_PELLETS[slot_data.default_kong]} 1 0": f"COND 24 | {KONG_PELLETS[pad_kong]} 1 0"})
                elif pad_type in (SwitchType.InstrumentPad, SwitchType.SlamSwitch):
                    if pad_kong == Kongs.any:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 25 | {slot_data.default_kong + 2} 0 0": "COND 0 | 0 0 0"})
                    else:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 25 | {slot_data.default_kong + 2} 0 0": f"COND 25 | {pad_kong + 2} 0 0"})
                elif pad_type in (SwitchType.PushableButton, SwitchType.PunchGrate, SwitchType.IceWall, SwitchType.Gong):
                    control_states = [
                        [0, 0],
                        [0x2E, 1],  # Chimpy Charge
                        [0, 0],
                        [0, 0],
                        [0x24, 2],  # Primate Punch
                    ]
                    if pad_type == SwitchType.Gong:
                        replaceScriptLines(
                            ROM_COPY,
                            slot_data.map_id,
                            slot_data.ids,
                            {
                                f"COND 23 | {control_states[slot_data.default_kong][0]} {control_states[slot_data.default_kong][1]} 0": f"COND 23 | {control_states[pad_kong][0]} {control_states[pad_kong][1]} 0"
                            },
                        )
                    elif slot == Switches.AztecOKONGPuzzle:
                        ids = [
                            0x0C,
                            0x0D,
                            0x0E,
                            0x0F,
                            0x14,
                        ]
                        replaceScriptLines(
                            ROM_COPY,
                            slot_data.map_id,
                            ids,
                            {
                                f"COND 23 | {control_states[slot_data.default_kong][0]} {control_states[slot_data.default_kong][1]} 0": f"COND 23 | {control_states[pad_kong][0]} {control_states[pad_kong][1]} 0"
                            },
                        )
                    else:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 23 | {control_states[slot_data.default_kong][0]} 0 0": f"COND 23 | {control_states[pad_kong][0]} 0 0"})
                        replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 33 | {control_states[slot_data.default_kong][1]} 0 0": f"COND 33 | {control_states[pad_kong][1]} 0 0"})
                    replaceScriptLines(ROM_COPY, slot_data.map_id, slot_data.ids, {f"COND 24 | {slot_data.default_kong + 2} 1 0": f"COND 24 | {pad_kong + 2} 1 0"})
                elif pad_type == SwitchType.GunInstrumentCombo:
                    KONG_PELLETS = [48, 36, 42, 43, 38]
                    if pad_kong == Kongs.any:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, [slot_data.ids[0]], {f"COND 24 | {KONG_PELLETS[slot_data.default_kong]} 1 0": "COND 16 | 4 1 0"})
                        replaceScriptLines(ROM_COPY, slot_data.map_id, [slot_data.ids[1]], {f"COND 25 | {slot_data.default_kong + 2} 0 0": "COND 0 | 0 0 0"})
                    else:
                        replaceScriptLines(ROM_COPY, slot_data.map_id, [slot_data.ids[0]], {f"COND 24 | {KONG_PELLETS[slot_data.default_kong]} 1 0": f"COND 24 | {KONG_PELLETS[pad_kong]} 1 0"})
                        replaceScriptLines(ROM_COPY, slot_data.map_id, [slot_data.ids[1]], {f"COND 25 | {slot_data.default_kong + 2} 0 0": f"COND 25 | {pad_kong + 2} 0 0"})

    slam_req_values = {
        SlamRequirement.green: 1,
        SlamRequirement.blue: 2,
        SlamRequirement.red: 3,
    }
    req_val = slam_req_values[spoiler.settings.chunky_phase_slam_req_internal]
    replaceScriptLines(ROM_COPY, Maps.KroolChunkyPhase, [0xA], {"COND 37 | 2 0 0": f"COND 37 | {req_val} 0 0"})
    ROM_COPY.seek(sav + 0x1E3)
    ROM_COPY.write(req_val)

    if spoiler.settings.enable_tag_anywhere:
        ta_blocks = {
            Maps.AngryAztec: [0x24],
            Maps.CastleCrypt: [0xD, 0xE, 0xF],
            Maps.CastleDungeon: [0x4, 0x5, 0x6],
            Maps.CastleTree: [0x1, 0x9],
            Maps.FranticFactory: [0x15, 0x38, 0x37, 0x3B],
            Maps.AztecLlamaTemple: [0x6B],
            Maps.Isles: [0x32, 0x2A, 0x27, 0x29, 0x28],
        }
        for map_id, obj_ids in ta_blocks.items():
            for x in range(5):
                replaceScriptLines(ROM_COPY, map_id, obj_ids, {f"CONDINV 25 | {x + 2} 0 0": "COND 25 | 0 0 0"})

    # Camera unlocked
    given_moves = []
    if spoiler.settings.shockwave_status == ShockwaveStatus.start_with:
        given_moves.extend([39, 40])  # 39 = Camera, 40 = Shockwave
        setItemReferenceName(spoiler, Items.CameraAndShockwave, 0, "Extra Training", 0)

    writeMultiselector(
        spoiler.settings.misc_changes_selected,
        QoLSelector,
        MiscChangesSelected,
        4,
        ROM_COPY,
        sav + 0x0B0,
    )
    writeMultiselector(
        spoiler.settings.faster_checks_selected,
        FasterCheckSelector,
        FasterChecksSelected,
        2,
        ROM_COPY,
        sav + 0x1E0,
    )
    writeMultiselector(
        spoiler.settings.hard_mode_selected,
        HardSelector,
        HardModeSelected,
        1,
        ROM_COPY,
        sav + 0x0C6,
    )

    is_dw = IsDDMSSelected(spoiler.settings.hard_mode_selected, HardModeSelected.donk_in_the_dark_world)
    is_sky = IsDDMSSelected(spoiler.settings.hard_mode_selected, HardModeSelected.donk_in_the_sky)
    ROM_COPY.seek(sav + 0x0C6)
    old = int.from_bytes(ROM_COPY.readBytes(1), "big")
    new = old
    if is_dw and is_sky:
        # Memory Challenge
        new = old | (0x8 | 0x2)
    elif is_dw and not is_sky:
        # Dark world only
        new = old | 0x8
    elif is_sky and not is_dw:
        # Sky only
        new = old | 0x4
    if new != old:
        ROM_COPY.seek(sav + 0x0C6)
        ROM_COPY.write(new)

    # Damage amount
    damage_multipliers = {
        DamageAmount.default: 1,
        DamageAmount.double: 2,
        DamageAmount.quad: 4,
        DamageAmount.ohko: 12,
    }
    ROM_COPY.seek(sav + 0x097)
    ROM_COPY.write(damage_multipliers[spoiler.settings.damage_amount])

    ROM_COPY.seek(sav + 0x0C5)
    ROM_COPY.write(int(Types.Enemies in spoiler.settings.shuffled_location_types))

    ROM_COPY.seek(sav + 0x0C2)
    hints_in_pool_handler = 0
    if Types.Hint in spoiler.settings.shuffled_location_types:
        hints_in_pool_handler = 1
        if spoiler.settings.progressive_hint_item != ProgressiveHintItem.off:
            hints_in_pool_handler = 2
    ROM_COPY.write(int(hints_in_pool_handler))

    # Progressive Hints
    count = 0
    if spoiler.settings.progressive_hint_item != ProgressiveHintItem.off:
        count = spoiler.settings.progressive_hint_count
        ROM_COPY.seek(sav + 0x0C3)
        ROM_COPY.write(getProgHintBarrierItem(spoiler.settings.progressive_hint_item))
        for x in range(10):
            ROM_COPY.seek(sav + 0x98 + (x * 2))
            ROM_COPY.writeMultipleBytes(getHintRequirementBatch(x, count, spoiler.settings.progressive_hint_algorithm), 2)
    ROM_COPY.seek(sav + 0x115)
    ROM_COPY.writeMultipleBytes(count, 1)

    # Item Locked Hint Doors
    if spoiler.settings.hint_door_item != ProgressiveHintItem.off:
        count = spoiler.settings.hint_door_item_count
        ROM_COPY.seek(sav + 0x1E5)
        ROM_COPY.write(getProgHintBarrierItem(spoiler.settings.hint_door_item))
        for x in range(7):
            ROM_COPY.seek(sav + 0x13C + (x * 2))
            req = spoiler.settings.hint_door_item_counts_level[x]
            if req > count:
                req = count
            ROM_COPY.writeMultipleBytes(req, 2)

    # Microhints
    ROM_COPY.seek(sav + 0x102)
    # The MicrohintsEnabled enum is indexed to allow this.
    ROM_COPY.write(int(spoiler.settings.microhints_enabled))

    # Cutscene Skip Setting
    ROM_COPY.seek(sav + 0x116)
    # The MicrohintsEnabled enum is indexed to allow this.
    ROM_COPY.write(int(spoiler.settings.more_cutscene_skips))

    # Helm Hurry
    helm_hurry_bonuses = [
        spoiler.settings.helmhurry_list_starting_time,
        spoiler.settings.helmhurry_list_golden_banana,
        spoiler.settings.helmhurry_list_blueprint,
        spoiler.settings.helmhurry_list_company_coins,
        spoiler.settings.helmhurry_list_move,
        spoiler.settings.helmhurry_list_banana_medal,
        spoiler.settings.helmhurry_list_rainbow_coin,
        spoiler.settings.helmhurry_list_boss_key,
        spoiler.settings.helmhurry_list_battle_crown,
        spoiler.settings.helmhurry_list_bean,
        spoiler.settings.helmhurry_list_pearl,
        spoiler.settings.helmhurry_list_kongs,
        spoiler.settings.helmhurry_list_fairies,
        spoiler.settings.helmhurry_list_colored_bananas,
        spoiler.settings.helmhurry_list_ice_traps,
    ]
    ROM_COPY.seek(sav + 0xE2)
    for bonus in helm_hurry_bonuses:
        if bonus < 0:
            bonus += 65536
        ROM_COPY.writeMultipleBytes(bonus, 2)

    # Activate Bananaports
    ROM_COPY.seek(sav + 0x138)
    # The ActivateAllBananaports enum is indexed to allow this.
    ROM_COPY.write(int(spoiler.settings.activate_all_bananaports))

    # Fast GBs - Change jetpac text
    if IsDDMSSelected(spoiler.settings.faster_checks_selected, FasterChecksSelected.jetpac) and spoiler.settings.jetpac_custom_minigame is None:
        data = {"textbox_index": ItemPreview.JetpacIntro, "mode": "replace", "search": "5000", "target": "2500"}
        for file in [CompTextFiles.PreviewsFlavor, CompTextFiles.PreviewsNormal]:
            if file in spoiler.text_changes:
                spoiler.text_changes[file].append(data)
            else:
                spoiler.text_changes[file] = [data]

    # Win Condition
    win_con_table = {
        WinConditionComplex.beat_krool: {
            "index": WinConROM.krool,
        },
        WinConditionComplex.get_key8: {"index": WinConROM.reqitem_solo, "item": ReqItems.Key, "level": 7},
        WinConditionComplex.get_keys_3_and_8: {
            "index": WinConROM.tasks_nopause,
            "tasks": [
                {"index": WinConROM.reqitem_solo, "item": ReqItems.Key, "level": 2},
                {"index": WinConROM.reqitem_solo, "item": ReqItems.Key, "level": 7},
            ],
        },
        WinConditionComplex.krem_kapture: {
            "index": WinConROM.krem_kapture,
        },
        WinConditionComplex.dk_rap_items: {
            "index": WinConROM.rap,
        },
        WinConditionComplex.krools_challenge: {
            "index": WinConROM.tasks_nopause,
            "tasks": [
                {"index": WinConROM.custom_item, "item": ReqItems.Key, "count": 8},
                {"index": WinConROM.custom_item, "item": ReqItems.Bosses, "count": 7},
                {"index": WinConROM.custom_item, "item": ReqItems.Blueprint, "count": 40},
                {"index": WinConROM.custom_item, "item": ReqItems.BonusesNoHelm, "count": 43},
            ],
        },
        WinConditionComplex.kill_the_rabbit: {"index": WinConROM.flag, "flag": 0x2E9},  # Rabbit Killed Flag
        WinConditionComplex.mech_fish: {"index": WinConROM.flag, "flag": 167},
        WinConditionComplex.arcade: {"index": WinConROM.flag, "flag": 132},  # Arcade R2
        WinConditionComplex.jetpac: {"index": WinConROM.flag, "flag": 379},
        WinConditionComplex.bad_hit_detection_man: {"index": WinConROM.flag, "flag": 660},
        WinConditionComplex.rareware_gb_check: {"index": WinConROM.flag, "flag": 301},
        WinConditionComplex.blast_courses: {
            "index": WinConROM.custom_item,
            "item": ReqItems.BlastCourses,
        },
        WinConditionComplex.req_bean: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Bean,
        },
        WinConditionComplex.req_bp: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Blueprint,
        },
        WinConditionComplex.req_companycoins: {
            "index": WinConROM.custom_item,
            "item": ReqItems.CompanyCoin,
        },
        WinConditionComplex.req_crown: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Crown,
        },
        WinConditionComplex.req_fairy: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Fairy,
        },
        WinConditionComplex.req_gb: {
            "index": WinConROM.custom_item,
            "item": ReqItems.GoldenBanana,
        },
        WinConditionComplex.req_pearl: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Pearl,
        },
        WinConditionComplex.req_key: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Key,
        },
        WinConditionComplex.req_medal: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Medal,
        },
        WinConditionComplex.req_rainbowcoin: {
            "index": WinConROM.custom_item,
            "item": ReqItems.RainbowCoin,
        },
        WinConditionComplex.req_bonuses: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Bonuses,
        },
        WinConditionComplex.req_bosses: {
            "index": WinConROM.custom_item,
            "item": ReqItems.Bosses,
        },
    }
    win_con = spoiler.settings.win_condition_item
    win_con_data = win_con_table.get(win_con, None)
    if win_con_data is not None:
        win_con_index = win_con_data["index"]
        ROM_COPY.seek(sav + 0x11D)
        ROM_COPY.write(win_con_index)
        if win_con_index == WinConROM.flag:
            ROM_COPY.seek(sav + 0xC0)
            ROM_COPY.writeMultipleBytes(win_con_data["flag"], 2)
        elif win_con_index == WinConROM.reqitem_solo:  # Req Item Solo
            ROM_COPY.seek(sav + 0xC0)
            ROM_COPY.write(win_con_data["item"])
            ROM_COPY.write(win_con_data["level"])
        elif win_con_index in (WinConROM.tasks, WinConROM.tasks_nopause):
            for task_index, task in enumerate(win_con_data["tasks"]):
                ROM_COPY.seek(sav + (4 * task_index))
                ROM_COPY.write(1)  # Task active
                task_type = task["index"]
                ROM_COPY.write(task_type)
                if task_type == WinConROM.flag:
                    ROM_COPY.writeMultipleBytes(task["flag"], 2)
                elif task_type == WinConROM.reqitem_solo:
                    ROM_COPY.write(task["item"])
                    ROM_COPY.write(task["level"])
                elif "item" in task:
                    ROM_COPY.write(task["item"])
                    ROM_COPY.write(task["count"])
        elif win_con_index == WinConROM.krem_kapture:
            ROM_COPY.seek(sav + 0xC0)
            ROM_COPY.writeMultipleBytes(spoiler.settings.win_condition_count, 2)
        else:
            if "item" in win_con_data:  # Custom Item
                ROM_COPY.seek(sav + 0xC0)
                ROM_COPY.write(win_con_data["item"])
                ROM_COPY.write(spoiler.settings.win_condition_count)
    elif win_con == WinConditionComplex.tasks:
        task_segments = [
            {"type": spoiler.settings.task_1_condition, "count": spoiler.settings.task_1_count},
            {"type": spoiler.settings.task_2_condition, "count": spoiler.settings.task_2_count},
            {"type": spoiler.settings.task_3_condition, "count": spoiler.settings.task_3_count},
            {"type": spoiler.settings.task_4_condition, "count": spoiler.settings.task_4_count},
            {"type": spoiler.settings.task_5_condition, "count": spoiler.settings.task_5_count},
            {"type": spoiler.settings.task_6_condition, "count": spoiler.settings.task_6_count},
            {"type": spoiler.settings.task_7_condition, "count": spoiler.settings.task_7_count},
            {"type": spoiler.settings.task_8_condition, "count": spoiler.settings.task_8_count},
        ]
        ROM_COPY.seek(sav + 0x11D)
        ROM_COPY.write(WinConROM.tasks)
        for task_index in range(8):
            ROM_COPY.seek(sav + (4 * task_index))
            ROM_COPY.write(0)
        task_index = 0
        for task in task_segments:
            win_con_data = win_con_table.get(task["type"], None)
            if win_con_data is not None:
                task_type = win_con_data["index"]
                ROM_COPY.seek(sav + (4 * task_index))
                ROM_COPY.write(1)  # Task active
                ROM_COPY.write(task_type)
                if task_type == WinConROM.flag:
                    ROM_COPY.writeMultipleBytes(win_con_data["flag"], 2)
                elif task_type == WinConROM.reqitem_solo:
                    ROM_COPY.write(win_con_data["item"])
                    ROM_COPY.write(win_con_data["level"])
                elif task_type == WinConROM.krem_kapture:
                    ROM_COPY.writeMultipleBytes(task["count"], 2)
                elif "item" in win_con_data:
                    ROM_COPY.write(win_con_data["item"])
                    ROM_COPY.write(task["count"])
                task_index += 1

    # Fungi Time of Day
    fungi_times = (FungiTimeSetting.day, FungiTimeSetting.night, FungiTimeSetting.dusk, FungiTimeSetting.progressive)
    progressive_removals = [5, 4]  # Day Switch, Night Switch
    day_script = {
        Maps.FungiForest: [
            0xC,  # Day Gate - Mill Front Entry
            0xE,  # Day Gate - Punch Door
            0x12,  # Day Gate - Snide Area
        ],
        Maps.ForestMillFront: [0xB],  # Day Gate - Mill Front
        Maps.ForestMillBack: [0xF],  # Day Gate - Mill Rear
    }
    night_script = {
        Maps.FungiForest: [
            8,  # Night Gate - Mill Lanky Attic
            0xB,  # Night Gate - Mill Winch Attic
            0xD,  # Night Gate - Dark Attic
            0x11,  # Night Gate - Thornvine Area
            0x2A,  # Night Gate - Mill GB
            0x53,  # Night Gate - Owl Tree Diddy Coins
            0x48,  # Night Gate - Beanstalk T&S
            0x1F1,  # Night Gate - Mushroom Night Door
            0x46,  # Night Gate - Crown Trapdoor
        ],
        Maps.ForestGiantMushroom: [0x11],  # Night Gate - GMush Interior
        Maps.ForestMillBack: [0x2],  # Night Gate - Spider Web
    }
    time_val = spoiler.settings.fungi_time_internal
    if time_val in fungi_times:
        ROM_COPY.seek(sav + 0x1DB)
        ROM_COPY.write(fungi_times.index(time_val))
        if time_val in (FungiTimeSetting.progressive, FungiTimeSetting.dusk):
            addNewScript(ROM_COPY, Maps.FungiForest, progressive_removals, ScriptTypes.DeleteItem)
    for map_id, changes in day_script.items():
        replaceScriptLines(
            ROM_COPY,
            map_id,
            changes,
            {
                "CONDINV 38 | 16 0 0": "COND 6 | 7 65519 0",
                "COND 38 | 16 0 0": "CONDINV 6 | 7 65519 0",
            },
        )
    for map_id, changes in night_script.items():
        replaceScriptLines(
            ROM_COPY,
            map_id,
            changes,
            {
                "COND 38 | 16 0 0": "COND 6 | 7 65519 1",
                "CONDINV 38 | 16 0 0": "CONDINV 6 | 7 65519 1",
            },
        )

    if spoiler.settings.fast_start_beginning_of_game:
        # Write a null move to this spot if fast start beginning of game is on
        ROM_COPY.seek(spoiler.settings.move_location_data + (125 * 6))
        ROM_COPY.writeMultipleBytes(0, 2)
        ROM_COPY.writeMultipleBytes(0, 4)

    # ROM Flags
    rom_flags = 0
    rom_flags |= 0x80 if spoiler.settings.enable_plandomizer else 0
    rom_flags |= 0x40 if spoiler.settings.generate_spoilerlog else 0
    rom_flags |= 0x20 if spoiler.settings.has_password else 0
    rom_flags |= 0x10 if spoiler.settings.archipelago else 0
    if spoiler.settings.archipelago:
        # Write spoiler.settings.player_name to ROM ASCII only
        ROM_COPY.seek(0x1FF3000)
        # Player name
        player_name = spoiler.settings.player_name[:16]
        # if we're shot on characters, pad with null bytes if we're short on characters
        if len(player_name) < 16:
            player_name += "\0" * (16 - len(player_name))
        # Convert playername to a bytestring and write it to the ROM
        bytestring = str(player_name).encode("ascii")
        ROM_COPY.writeBytes(bytestring)
    ROM_COPY.seek(sav + 0xC4)
    ROM_COPY.writeMultipleBytes(rom_flags, 1)
    password = None
    if spoiler.settings.has_password:
        ROM_COPY.seek(sav + 0x1B0)
        byte_data, password = encPass(spoiler)
        ROM_COPY.writeMultipleBytes(byte_data, 4)

    # Set K. Rool ship spawn method
    ROM_COPY.seek(sav + 0x1B6)
    # Write the user's setting directly - beat_krool/krools_challenge will use key-based spawning unless this is explicitly enabled
    ROM_COPY.writeMultipleBytes(spoiler.settings.win_condition_spawns_ship, 1)

    # Mill Levers
    if spoiler.settings.mill_levers[0] > 0:
        mill_text = ""
        for x in range(5):
            if spoiler.settings.mill_levers[x] > 0:
                mill_text += str(spoiler.settings.mill_levers[x])
        # Change default wrinkly hint
        if spoiler.settings.wrinkly_hints == WrinklyHints.off:
            if (
                IsDDMSSelected(
                    spoiler.settings.faster_checks_selected,
                    FasterChecksSelected.forest_mill_conveyor,
                )
                or spoiler.settings.puzzle_rando_difficulty != PuzzleRando.off
            ):
                data = {"textbox_index": 21, "mode": "replace", "search": "21132", "target": mill_text}
                for file in [CompTextFiles.Wrinkly]:
                    if file in spoiler.text_changes:
                        spoiler.text_changes[file].append(data)
                    else:
                        spoiler.text_changes[file] = [data]

    ROM_COPY.seek(sav + 0x36)
    ROM_COPY.write(spoiler.settings.rareware_gb_fairies)

    ROM_COPY.seek(sav + 0x1EB)
    ROM_COPY.write(spoiler.settings.mermaid_gb_pearls)

    if spoiler.settings.random_starting_region_new != RandomStartingRegion.off:
        ROM_COPY.seek(sav + 0x10C)
        ROM_COPY.write(spoiler.settings.starting_region["map"])
        exit_val = spoiler.settings.starting_region["exit"]
        if exit_val == -1:
            exit_val = 0xFF
        ROM_COPY.write(exit_val)
    if spoiler.settings.alter_switch_allocation:
        setProgSlamStrength(ROM_COPY, spoiler.settings)
    # Dartboard order
    DARTBOARD_IMAGES = [3, 1, 2, 0, 5, 4, 6, 7]
    DARTBOARD_DEFAULT_ORDER = [4, 2, 3, 1, 6, 5]
    for x in range(6):
        # Conversion to prevent repeated overwrites
        replaceScriptLines(ROM_COPY, Maps.FranticFactory, [0x7F], {f"EXEC 40 | 1 {x} 0": f"EXEC 40 | 1 {x} 1"})
        replaceScriptLines(
            ROM_COPY,
            Maps.FranticFactory,
            [0x7F],
            {
                f"COND 24 | 43 {DARTBOARD_DEFAULT_ORDER[x]} 0": f"COND 24 | 43 {DARTBOARD_DEFAULT_ORDER[x]} 1",
            },
        )
        replaceScriptLines(
            ROM_COPY,
            Maps.FranticFactory,
            [0x7F],
            {
                f"CONDINV 24 | 43 {DARTBOARD_DEFAULT_ORDER[x]} 0": f"CONDINV 24 | 43 {DARTBOARD_DEFAULT_ORDER[x]} 1",
            },
        )
    for x in range(6):
        index = spoiler.settings.dartboard_order[x]
        replaceScriptLines(ROM_COPY, Maps.FranticFactory, [0x7F], {f"EXEC 40 | 1 {x} 1": f"EXEC 40 | 1 {DARTBOARD_IMAGES[index]} 0"})
        replaceScriptLines(
            ROM_COPY,
            Maps.FranticFactory,
            [0x7F],
            {
                f"COND 24 | 43 {DARTBOARD_DEFAULT_ORDER[x]} 1": f"COND 24 | 43 {index + 1} 0",
            },
        )
        replaceScriptLines(
            ROM_COPY,
            Maps.FranticFactory,
            [0x7F],
            {
                f"CONDINV 24 | 43 {DARTBOARD_DEFAULT_ORDER[x]} 1": f"CONDINV 24 | 43 {index + 1} 0",
            },
        )

    ROM_COPY.seek(sav + 0x060)
    for x in spoiler.settings.medal_cb_req_level:
        ROM_COPY.writeMultipleBytes(x, 1)
    if Types.HalfMedal in spoiler.settings.shuffled_location_types:
        ROM_COPY.seek(sav + 0x068)
        ROM_COPY.write(1)
        ROM_COPY.seek(sav + 0x1E7)
        ROM_COPY.write(spoiler.settings.half_medal_percentage)

    # Helm Required Minigames - Always set to 2 for now
    ROM_COPY.seek(sav + 0x2D)
    ROM_COPY.write(int(spoiler.settings.helm_room_bonus_count))

    if spoiler.settings.wrinkly_hints != WrinklyHints.off:
        getHelmOrderHint(spoiler)
    randomize_entrances(spoiler, ROM_COPY)
    randomize_moves(spoiler, ROM_COPY)
    randomize_prices(spoiler, ROM_COPY)
    randomize_krool(spoiler, ROM_COPY)
    randomize_helm(spoiler, ROM_COPY)
    randomize_barrels(spoiler, ROM_COPY)
    move_bananaports(spoiler, ROM_COPY)  # Has to be before randomize_bananaport
    randomize_bananaport(spoiler, ROM_COPY)
    randomize_kasplat_locations(spoiler, ROM_COPY)
    randomize_enemies(spoiler, ROM_COPY)
    apply_kongrando_cosmetic(ROM_COPY)
    randomize_setup(spoiler, ROM_COPY)
    randomize_puzzles(spoiler, ROM_COPY)
    PlaceShip(spoiler, ROM_COPY)
    randomize_cbs(spoiler, ROM_COPY)
    randomize_coins(spoiler, ROM_COPY)
    place_mayhem_coins(spoiler, ROM_COPY)
    ApplyShopRandomizer(spoiler, ROM_COPY)
    remove5DSCameraPoint(spoiler, ROM_COPY)
    alterTextboxRequirements(spoiler)
    spoiler.arcade_item_reward = Items.NintendoCoin
    spoiler.jetpac_item_reward = Items.RarewareCoin
    place_randomized_items(spoiler, ROM_COPY)  # Has to be after kong rando cosmetic and moves
    place_spoiler_hint_data(sav, spoiler, ROM_COPY)
    # Arcade detection for colorblind mode
    arcade_item_index = 0
    potion_pools = [
        ItemPool.DonkeyMoves,
        ItemPool.DiddyMoves,
        ItemPool.LankyMoves,
        ItemPool.TinyMoves,
        ItemPool.ChunkyMoves,
        ItemPool.ImportantSharedMoves
        + ItemPool.JunkSharedMoves
        + ItemPool.TrainingBarrelAbilities()
        + ItemPool.ClimbingAbilities()
        + ItemPool.CannonAbilities()
        + [Items.Shockwave, Items.Camera, Items.CameraAndShockwave],
    ]
    for index, lst in enumerate(potion_pools):
        if spoiler.arcade_item_reward in lst:
            arcade_item_index = 1 + index
    ROM_COPY.seek(sav + 0x15A)
    ROM_COPY.writeMultipleBytes(arcade_item_index, 1)
    # Other funcs
    place_pregiven_moves(spoiler, ROM_COPY)
    remove_existing_indicators(spoiler, ROM_COPY)
    place_door_locations(spoiler, ROM_COPY)
    randomize_crown_pads(spoiler, ROM_COPY)
    randomize_melon_crate(spoiler, ROM_COPY)
    PlaceFairies(spoiler, ROM_COPY)
    filterEntranceType(ROM_COPY)
    updateKrushaMoveNames(spoiler)
    updateSwitchsanity(spoiler, ROM_COPY)
    updateRandomSwitches(spoiler, ROM_COPY)  # Has to be after all setup changes that may alter the item type of slam switches
    PushItemLocations(spoiler, ROM_COPY)

    if spoiler.settings.wrinkly_hints != WrinklyHints.off:
        PushHints(spoiler, ROM_COPY)
        if spoiler.settings.dim_solved_hints:
            PushHelpfulHints(spoiler, ROM_COPY)
    if Types.Hint in spoiler.settings.shuffled_location_types and spoiler.settings.progressive_hint_item == ProgressiveHintItem.off:
        PushHintTiedRegions(spoiler, ROM_COPY)

    writeBootMessages(ROM_COPY, spoiler)
    enableTriggerText(spoiler, ROM_COPY)
    shortenCastleMinecart(spoiler, ROM_COPY)
    alterStoryCutsceneWarps(spoiler, ROM_COPY)

    if "PYTEST_CURRENT_TEST" not in os.environ:
        updateMillLeverTexture(spoiler.settings, ROM_COPY)
        updateCryptLeverTexture(spoiler.settings, ROM_COPY)
        updateDiddyDoors(spoiler.settings, ROM_COPY)
        applyHelmDoorCosmetics(spoiler.settings, ROM_COPY)
        applyKongModelSwaps(spoiler.settings, ROM_COPY)
        updateHelmFaces(spoiler.settings, ROM_COPY)
        updateSnidePanel(spoiler.settings, ROM_COPY)
        showWinCondition(spoiler.settings, ROM_COPY)
        addBalloonBulb(spoiler.settings, ROM_COPY, ColorblindMode.off)

        patchAssembly(ROM_COPY, spoiler)
        patchScripts(spoiler, ROM_COPY)
        replaceIngameText(spoiler, ROM_COPY)
        calculateInitFileScreen(spoiler, ROM_COPY)
        ApplyMirrorMode(spoiler.settings, ROM_COPY)

    precalcBoot(ROM_COPY, spoiler)  # Needs to be done after any updates to setup for CBs, patches and crates

    # Apply Hash
    order = 0
    for count in spoiler.settings.seed_hash:
        ROM_COPY.seek(sav + 0x129 + order)
        ROM_COPY.write(count)
        order += 1

    # Create a dummy time to attach to the end of the file name non decimal
    str(time.time()).replace(".", "")

    # Check if this is the browser path (applying proto to provided ROM)
    # or the server path (creating proto for .lanky file)
    if rom is not None:
        # Browser path: ROM patching is complete, don't delete ROM, don't return proto
        # ROM_COPY is the provided rom parameter - caller will handle it
        return None, password
    else:
        # Server path: Return serialized FillResult proto for .lanky file creation
        # The proto contains all fill data needed to reconstruct the ROM patch client-side
        if isinstance(fill_result_or_spoiler, fill_result_pb2.FillResult):
            # Already have proto - serialize it to bytes
            proto_bytes = fill_result_or_spoiler.SerializeToString()
            patch = proto_bytes
        else:
            # Legacy path - convert spoiler to proto then serialize
            fill_result_proto = fill_result_to_proto(spoiler)
            proto_bytes = fill_result_proto.SerializeToString()
            patch = proto_bytes

        del ROM_COPY
        return patch, password


def FormatSpoiler(value):
    """Format the values passed to the settings table into a more readable format.

    Args:
        value (str) or (bool)
    """
    string = str(value)
    formatted = string.replace("_", " ")
    result = formatted.title()
    return result
