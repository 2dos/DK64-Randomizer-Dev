"""Functions to write ASM data to ROM."""
